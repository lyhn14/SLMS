<?php include('header.php'); ?>
<?php include('session.php'); ?>
<?php include('navbar_dashboard.php'); ?>
    <div class="container">
		<div class="margin-top">
			<div class="row">	
			<div class="span12">		
                       
			<div class="span12">
				<div class="header">
				<div class="pull-left">
				<style>
  .stilogo {
    width: 1375px;
    height: 525px;
  }
</style>

<img class="stilogo" src="../LMS/E.B. Magalona.png">

				</div>
				</div>
				<div id="logout" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
		<div class="modal-body">
			<div class="alert alert-error">Are you sure you want to Logout?</div>
		</div>
		<div class="modal-footer">
			<button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;NO</button>
			<a href="logout.php" class="btn btn-danger"><i class="icon-check icon-large"></i>&nbsp;Yes</a>
		</div>
    </div>
				
			</div>		
			</div>
		</div>
    </div>
<?php include('footer.php') ?>