<div class="navbar navbar-fixed-top navbar-inverse">
    <div class="navbar-inner">
        <div class="container">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </a>
            <div class="nav-collapse collapse">
                <ul class="nav">
                    <li class="active"><a href="users.php"><i class="icon-user icon-large"></i>&nbsp;Users</a></li>
                    <li><a href="index.php"><i class="icon-home icon-large"></i>&nbsp;Log In</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php include('search_form.php'); ?>
