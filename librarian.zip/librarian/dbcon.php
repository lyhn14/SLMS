<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_slms') or die(mysqli_error($conn));
?>
